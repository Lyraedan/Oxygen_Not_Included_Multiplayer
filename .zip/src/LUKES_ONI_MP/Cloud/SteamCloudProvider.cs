using System;
using UnityEngine.Events;

namespace ONI_MP.Cloud
{
    /// <summary>
    /// Steam Cloud provider implementation.
    /// </summary>
    public class SteamCloudProvider : ICloudStorageProvider
    {
        public bool IsInitialized => SteamCloud.Instance.IsInitialized;
        public string ProviderName => "SteamCloud";

        public UnityEvent OnUploadStarted { get; } = new UnityEvent();
        public UnityEvent<string> OnUploadFinished { get; } = new UnityEvent<string>();
        public UnityEvent<Exception> OnUploadFailed { get; } = new UnityEvent<Exception>();
        public UnityEvent OnDownloadStarted { get; } = new UnityEvent();
        public UnityEvent<string> OnDownloadFinished { get; } = new UnityEvent<string>();
        public UnityEvent<Exception> OnDownloadFailed { get; } = new UnityEvent<Exception>();

        public void Initialize()
        {
            SteamCloud.Instance.Initialize();
            
            if (IsInitialized)
            {
                // Connect Steam Cloud events to provider events
                SteamCloud.Instance.Uploader.OnUploadStarted.AddListener(() => OnUploadStarted.Invoke());
                SteamCloud.Instance.Uploader.OnUploadFinished.AddListener((fileName) => OnUploadFinished.Invoke(fileName));
                SteamCloud.Instance.Uploader.OnUploadFailed.AddListener((ex) => OnUploadFailed.Invoke(ex));
                
                SteamCloud.Instance.Downloader.OnDownloadStarted.AddListener(() => OnDownloadStarted.Invoke());
                SteamCloud.Instance.Downloader.OnDownloadFinished.AddListener((filePath) => OnDownloadFinished.Invoke(filePath));
                SteamCloud.Instance.Downloader.OnDownloadFailed.AddListener((ex) => OnDownloadFailed.Invoke(ex));
            }
        }

        public void UploadFile(string localFilePath, string remoteFileName = null)
        {
            SteamCloud.Instance.Uploader.UploadFile(localFilePath, remoteFileName);
        }

        public void DownloadFile(string remoteFileName, string localFilePath)
        {
            SteamCloud.Instance.Downloader.DownloadFile(remoteFileName, localFilePath);
        }

        public string GetQuotaInfo()
        {
            return SteamCloudUtils.GetQuotaInfo();
        }

        public string[] ListFiles()
        {
            return SteamCloud.Instance.Uploader.GetSaveFileList();
        }
    }
}
