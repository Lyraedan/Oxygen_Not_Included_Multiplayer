using ONI_MP.DebugTools;
using ONI_MP.Menus;
using Steamworks;
using System;
using System.IO;
using UnityEngine;
using UnityEngine.Events;

namespace ONI_MP.Cloud
{
    /// <summary>
    /// Handles downloading files from Steam Cloud storage.
    /// </summary>
    public class SteamCloudDownloader
    {
        public UnityEvent OnDownloadStarted { get; } = new UnityEvent();
        public UnityEvent<string> OnDownloadFinished { get; } = new UnityEvent<string>();
        public UnityEvent<Exception> OnDownloadFailed { get; } = new UnityEvent<Exception>();

        public bool IsDownloading { get; private set; } = false;

        /// <summary>
        /// Downloads a file from Steam Cloud to a local path.
        /// </summary>
        /// <param name="cloudFileName">Name of the file in Steam Cloud</param>
        /// <param name="localDestinationPath">Local path where the file should be saved</param>
        public void DownloadFile(string cloudFileName, string localDestinationPath)
        {
            if (!SteamCloud.Instance.IsInitialized)
            {
                DebugConsole.LogError("SteamCloudDownloader: Steam Cloud not initialized!", false);
                OnDownloadFailed?.Invoke(new InvalidOperationException("Steam Cloud not initialized"));
                return;
            }

            if (!SteamCloud.Instance.FileExists(cloudFileName))
            {
                DebugConsole.LogError($"SteamCloudDownloader: File {cloudFileName} does not exist in Steam Cloud!", false);
                OnDownloadFailed?.Invoke(new FileNotFoundException($"File not found in Steam Cloud: {cloudFileName}"));
                return;
            }

            try
            {
                IsDownloading = true;
                OnDownloadStarted?.Invoke();
                MultiplayerOverlay.Show("Starting Steam Cloud download...");

                var startTime = System.DateTime.UtcNow;

                // Get file size
                int fileSize = SteamCloud.Instance.GetFileSize(cloudFileName);
                DebugConsole.Log($"SteamCloudDownloader: Downloading {cloudFileName} ({fileSize} bytes)");

                // Read file data from Steam Cloud
                byte[] fileData = new byte[fileSize];
                int bytesRead = SteamRemoteStorage.FileRead(cloudFileName, fileData, fileSize);

                if (bytesRead != fileSize)
                {
                    throw new InvalidOperationException($"Download size mismatch: expected {fileSize}, got {bytesRead}");
                }

                // Ensure destination directory exists
                string destinationDir = Path.GetDirectoryName(localDestinationPath);
                if (!Directory.Exists(destinationDir))
                {
                    Directory.CreateDirectory(destinationDir);
                }

                // Write to local file
                File.WriteAllBytes(localDestinationPath, fileData);

                // Verify the download
                if (!File.Exists(localDestinationPath))
                {
                    throw new InvalidOperationException("Download verification failed - local file was not created");
                }

                var localFileInfo = new FileInfo(localDestinationPath);
                if (localFileInfo.Length != fileSize)
                {
                    throw new InvalidOperationException($"Local file size mismatch: expected {fileSize}, got {localFileInfo.Length}");
                }

                var endTime = System.DateTime.UtcNow;
                var duration = endTime - startTime;
                double speedKBps = (fileSize / 1024.0) / duration.TotalSeconds;

                DebugConsole.Log($"SteamCloudDownloader: Successfully downloaded {cloudFileName} in {duration.TotalSeconds:F1}s ({speedKBps:F1} KB/s)");

                IsDownloading = false;
                MultiplayerOverlay.Show($"Download complete: {Path.GetFileName(localDestinationPath)}");
                OnDownloadFinished?.Invoke(localDestinationPath);
            }
            catch (Exception ex)
            {
                DebugConsole.LogError($"SteamCloudDownloader: Download failed: {ex.Message}", false);
                IsDownloading = false;
                MultiplayerOverlay.Show($"Download failed: {ex.Message}");
                OnDownloadFailed?.Invoke(ex);
            }
        }

        /// <summary>
        /// Downloads a file from Steam Cloud and returns its contents as a byte array.
        /// </summary>
        /// <param name="cloudFileName">Name of the file in Steam Cloud</param>
        /// <returns>File contents as byte array, or null if download failed</returns>
        public byte[] DownloadFileData(string cloudFileName)
        {
            if (!SteamCloud.Instance.IsInitialized)
            {
                DebugConsole.LogError("SteamCloudDownloader: Steam Cloud not initialized!", false);
                return null;
            }

            if (!SteamCloud.Instance.FileExists(cloudFileName))
            {
                DebugConsole.LogError($"SteamCloudDownloader: File {cloudFileName} does not exist in Steam Cloud!", false);
                return null;
            }

            try
            {
                int fileSize = SteamCloud.Instance.GetFileSize(cloudFileName);
                byte[] fileData = new byte[fileSize];
                int bytesRead = SteamRemoteStorage.FileRead(cloudFileName, fileData, fileSize);

                if (bytesRead != fileSize)
                {
                    DebugConsole.LogError($"SteamCloudDownloader: Data download size mismatch: expected {fileSize}, got {bytesRead}", false);
                    return null;
                }

                DebugConsole.Log($"SteamCloudDownloader: Successfully downloaded {cloudFileName} data ({fileSize} bytes)");
                return fileData;
            }
            catch (Exception ex)
            {
                DebugConsole.LogError($"SteamCloudDownloader: Data download failed: {ex.Message}", false);
                return null;
            }
        }

        /// <summary>
        /// Gets information about a file in Steam Cloud without downloading it.
        /// </summary>
        public (bool exists, int size, System.DateTime timestamp) GetFileInfo(string cloudFileName)
        {
            if (!SteamCloud.Instance.IsInitialized)
                return (false, 0, System.DateTime.MinValue);

            bool exists = SteamCloud.Instance.FileExists(cloudFileName);
            if (!exists)
                return (false, 0, System.DateTime.MinValue);

            int size = SteamCloud.Instance.GetFileSize(cloudFileName);
            System.DateTime timestamp = SteamCloud.Instance.GetFileTimestamp(cloudFileName);

            return (exists, size, timestamp);
        }

        /// <summary>
        /// Lists available save files in Steam Cloud with their metadata.
        /// </summary>
        public (string fileName, int size, System.DateTime timestamp)[] ListSaveFiles()
        {
            if (!SteamCloud.Instance.IsInitialized)
                return new (string, int, System.DateTime)[0];

            string[] saveFiles = SteamCloud.Instance.Uploader.GetSaveFileList();
            var fileInfo = new (string, int, System.DateTime)[saveFiles.Length];

            for (int i = 0; i < saveFiles.Length; i++)
            {
                var info = GetFileInfo(saveFiles[i]);
                fileInfo[i] = (saveFiles[i], info.size, info.timestamp);
            }

            return fileInfo;
        }
    }
}
