using ONI_MP.DebugTools;
using ONI_MP.Menus;
using ONI_MP.Misc;
using ONI_MP.Networking;
using ONI_MP.Networking.Packets.Architecture;
using ONI_MP.Networking.Packets.Cloud;
using Steamworks;
using System;
using System.IO;

namespace ONI_MP.Cloud
{
    /// <summary>
    /// Utility class for Steam Cloud operations, providing similar functionality to GoogleDriveUtils
    /// but using Steam Cloud instead of Google Drive.
    /// </summary>
    public class SteamCloudUtils
    {
        private const string SAVE_FILE_PREFIX = "ONI_MP_Save_";

        /// <summary>
        /// Uploads the current save file and sends sharing information to all clients.
        /// </summary>
        public static void UploadAndSendToAllClients()
        {
            if (!SteamCloud.Instance.IsInitialized)
            {
                DebugConsole.LogError("SteamCloudUtils: Steam Cloud not initialized!", false);
                return;
            }

            SteamCloud.Instance.Uploader.OnUploadFinished.RemoveAllListeners();
            SteamCloud.Instance.Uploader.OnUploadFinished.AddListener((cloudFileName) =>
            {
                string originalFileName = Path.GetFileName(SaveLoader.GetActiveSaveFilePath());

                var packet = new SteamCloudFileSharePacket
                {
                    FileName = originalFileName,
                    CloudFileName = cloudFileName,
                    FileSize = SteamCloud.Instance.GetFileSize(cloudFileName),
                    Timestamp = SteamCloud.Instance.GetFileTimestamp(cloudFileName)
                };

                PacketSender.SendToAllClients(packet);

                if (GameServerHardSync.IsHardSyncInProgress)
                {
                    GameServerHardSync.IsHardSyncInProgress = false;
                }
            });

            UploadSaveFile();
        }

        /// <summary>
        /// Uploads the current save file and sends sharing information to a specific client.
        /// </summary>
        public static void UploadAndSendToClient(CSteamID requester)
        {
            if (!SteamCloud.Instance.IsInitialized)
            {
                DebugConsole.LogError("SteamCloudUtils: Steam Cloud not initialized!", false);
                return;
            }

            SteamCloud.Instance.Uploader.OnUploadFinished.RemoveAllListeners();
            SteamCloud.Instance.Uploader.OnUploadFinished.AddListener((cloudFileName) =>
            {
                string originalFileName = Path.GetFileName(SaveLoader.GetActiveSaveFilePath());

                var packet = new SteamCloudFileSharePacket
                {
                    FileName = originalFileName,
                    CloudFileName = cloudFileName,
                    FileSize = SteamCloud.Instance.GetFileSize(cloudFileName),
                    Timestamp = SteamCloud.Instance.GetFileTimestamp(cloudFileName)
                };

                PacketSender.SendToPlayer(requester, packet);
            });

            UploadSaveFile();
        }

        /// <summary>
        /// Uploads the current save file to Steam Cloud.
        /// </summary>
        public static void UploadSaveFile()
        {
            if (!SteamCloud.Instance.IsInitialized)
            {
                DebugConsole.LogError("SteamCloudUtils: Steam Cloud not initialized!", false);
                return;
            }

            try
            {
                var path = SaveLoader.GetActiveSaveFilePath();
                SaveLoader.Instance.Save(path); // Saves current state to that file

                // Generate a unique cloud filename with timestamp
                string originalFileName = Path.GetFileName(path);
                string cloudFileName = $"{SAVE_FILE_PREFIX}{System.DateTime.UtcNow:yyyyMMdd_HHmmss}_{originalFileName}";

                DebugConsole.Log($"SteamCloudUtils: Uploading save file {originalFileName} as {cloudFileName}");
                SteamCloud.Instance.Uploader.UploadFile(path, cloudFileName);
            }
            catch (Exception ex)
            {
                DebugConsole.LogError($"SteamCloudUtils: Failed to upload save file: {ex.Message}", false);
            }
        }

        /// <summary>
        /// Downloads a save file from Steam Cloud and loads it.
        /// </summary>
        public static void DownloadAndLoadSaveFile(string cloudFileName, string localFileName)
        {
            if (!SteamCloud.Instance.IsInitialized)
            {
                DebugConsole.LogError("SteamCloudUtils: Steam Cloud not initialized!", false);
                return;
            }

            try
            {
                // Determine local save path
                string saveDir = Path.GetDirectoryName(SaveLoader.GetActiveSaveFilePath());
                string localPath = Path.Combine(saveDir, localFileName);

                DebugConsole.Log($"SteamCloudUtils: Downloading {cloudFileName} to {localPath}");

                SteamCloud.Instance.Downloader.OnDownloadFinished.RemoveAllListeners();
                SteamCloud.Instance.Downloader.OnDownloadFinished.AddListener((downloadPath) =>
                {
                    try
                    {
                        DebugConsole.Log($"SteamCloudUtils: Download complete, loading {localFileName}");
                        SaveLoader.Instance.Load(downloadPath);
                    }
                    catch (Exception ex)
                    {
                        DebugConsole.LogError($"SteamCloudUtils: Failed to load downloaded save: {ex.Message}", false);
                    }
                });

                SteamCloud.Instance.Downloader.OnDownloadFailed.RemoveAllListeners();
                SteamCloud.Instance.Downloader.OnDownloadFailed.AddListener((exception) =>
                {
                    DebugConsole.LogError($"SteamCloudUtils: Download failed: {exception.Message}", false);
                });

                SteamCloud.Instance.Downloader.DownloadFile(cloudFileName, localPath);
            }
            catch (Exception ex)
            {
                DebugConsole.LogError($"SteamCloudUtils: Failed to download save file: {ex.Message}", false);
            }
        }

        /// <summary>
        /// Gets information about available save files in Steam Cloud.
        /// </summary>
        public static (string cloudFileName, string originalFileName, int size, System.DateTime timestamp)[] GetAvailableSaveFiles()
        {
            if (!SteamCloud.Instance.IsInitialized)
                return new (string, string, int, System.DateTime)[0];

            try
            {
                var saveFiles = SteamCloud.Instance.Downloader.ListSaveFiles();
                var result = new (string, string, int, System.DateTime)[saveFiles.Length];

                for (int i = 0; i < saveFiles.Length; i++)
                {
                    string cloudFileName = saveFiles[i].fileName;
                    string originalFileName = ExtractOriginalFileName(cloudFileName);
                    int size = saveFiles[i].size;
                    System.DateTime timestamp = saveFiles[i].timestamp;

                    result[i] = (cloudFileName, originalFileName, size, timestamp);
                }

                return result;
            }
            catch (Exception ex)
            {
                DebugConsole.LogError($"SteamCloudUtils: Failed to get available save files: {ex.Message}", false);
                return new (string, string, int, System.DateTime)[0];
            }
        }

        /// <summary>
        /// Extracts the original filename from a Steam Cloud filename.
        /// </summary>
        private static string ExtractOriginalFileName(string cloudFileName)
        {
            if (cloudFileName.StartsWith(SAVE_FILE_PREFIX))
            {
                // Remove prefix and timestamp: "ONI_MP_Save_20250715_143022_"
                int lastUnderscoreIndex = cloudFileName.LastIndexOf('_');
                if (lastUnderscoreIndex > SAVE_FILE_PREFIX.Length)
                {
                    return cloudFileName.Substring(lastUnderscoreIndex + 1);
                }
            }

            return cloudFileName;
        }

        /// <summary>
        /// Cleans up old save files in Steam Cloud, keeping only the most recent ones.
        /// </summary>
        public static void CleanupOldSaveFiles(int maxFilesToKeep = 10)
        {
            if (!SteamCloud.Instance.IsInitialized)
                return;

            try
            {
                var saveFiles = SteamCloud.Instance.Downloader.ListSaveFiles();
                
                if (saveFiles.Length <= maxFilesToKeep)
                    return;

                // Sort by timestamp, newest first
                Array.Sort(saveFiles, (a, b) => ((System.DateTime)b.timestamp).CompareTo((System.DateTime)a.timestamp));

                // Delete older files
                for (int i = maxFilesToKeep; i < saveFiles.Length; i++)
                {
                    string fileToDelete = saveFiles[i].fileName;
                    DebugConsole.Log($"SteamCloudUtils: Cleaning up old save file: {fileToDelete}");
                    SteamCloud.Instance.Uploader.DeleteFile(fileToDelete);
                }

                DebugConsole.Log($"SteamCloudUtils: Cleaned up {saveFiles.Length - maxFilesToKeep} old save files");
            }
            catch (Exception ex)
            {
                DebugConsole.LogError($"SteamCloudUtils: Failed to cleanup old save files: {ex.Message}", false);
            }
        }

        /// <summary>
        /// Gets Steam Cloud quota information as a formatted string.
        /// </summary>
        public static string GetQuotaInfo()
        {
            if (!SteamCloud.Instance.IsInitialized)
                return "Steam Cloud not initialized";

            var (totalBytes, availableBytes) = SteamCloud.Instance.GetQuota();
            long usedBytes = (long)(totalBytes - availableBytes);

            return $"Steam Cloud: {FormatBytes(usedBytes)} / {FormatBytes((long)totalBytes)} used ({FormatBytes((long)availableBytes)} available)";
        }

        private static string FormatBytes(long bytes)
        {
            if (bytes < 1024)
                return $"{bytes} B";
            else if (bytes < 1024 * 1024)
                return $"{bytes / 1024.0:F1} KB";
            else if (bytes < 1024 * 1024 * 1024)
                return $"{bytes / (1024.0 * 1024.0):F1} MB";
            else
                return $"{bytes / (1024.0 * 1024.0 * 1024.0):F1} GB";
        }
    }
}
