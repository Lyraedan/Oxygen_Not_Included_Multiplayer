using ONI_MP.DebugTools;
using ONI_MP.Menus;
using ONI_MP.Networking.Components;
using Steamworks;
using System;
using System.IO;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;

namespace ONI_MP.Cloud
{
    /// <summary>
    /// Handles uploading files to Steam Cloud storage.
    /// </summary>
    public class SteamCloudUploader
    {
        public UnityEvent OnUploadStarted { get; } = new UnityEvent();
        public UnityEvent<string> OnUploadFinished { get; } = new UnityEvent<string>();
        public UnityEvent<Exception> OnUploadFailed { get; } = new UnityEvent<Exception>();

        public bool IsUploading { get; private set; } = false;

        private const int MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB Steam Cloud limit
        private const string SAVE_FILE_PREFIX = "ONI_MP_Save_";

        /// <summary>
        /// Uploads a local file to Steam Cloud.
        /// </summary>
        /// <param name="localFilePath">Path to the local file</param>
        /// <param name="cloudFileName">Optional custom name for the file in Steam Cloud</param>
        public async void UploadFile(string localFilePath, string cloudFileName = null)
        {
            if (!SteamCloud.Instance.IsInitialized)
            {
                DebugConsole.LogError("SteamCloudUploader: Steam Cloud not initialized!", false);
                OnUploadFailed?.Invoke(new InvalidOperationException("Steam Cloud not initialized"));
                return;
            }

            if (!File.Exists(localFilePath))
            {
                DebugConsole.LogError($"SteamCloudUploader: file not found at {localFilePath}", false);
                OnUploadFailed?.Invoke(new FileNotFoundException("Upload file missing", localFilePath));
                return;
            }

            try
            {
                IsUploading = true;
                OnUploadStarted?.Invoke();
                MultiplayerOverlay.Show("Starting Steam Cloud upload...");

                // Generate cloud filename if not provided
                if (string.IsNullOrEmpty(cloudFileName))
                {
                    cloudFileName = SAVE_FILE_PREFIX + Path.GetFileName(localFilePath);
                }

                await Task.Run(() => UploadFileInternal(localFilePath, cloudFileName));
            }
            catch (Exception ex)
            {
                DebugConsole.LogError($"SteamCloudUploader: Upload failed: {ex.Message}", false);
                OnUploadFailed?.Invoke(ex);
                MultiplayerOverlay.Show($"Upload failed: {ex.Message}");
                IsUploading = false;
            }
        }

        private void UploadFileInternal(string localFilePath, string cloudFileName)
        {
            try
            {
                // Read the file data
                byte[] fileData = File.ReadAllBytes(localFilePath);

                // Check file size limits
                if (fileData.Length > MAX_FILE_SIZE)
                {
                    throw new InvalidOperationException($"File too large: {fileData.Length} bytes. Steam Cloud limit is {MAX_FILE_SIZE} bytes.");
                }

                // Check Steam Cloud quota
                var (totalBytes, availableBytes) = SteamCloud.Instance.GetQuota();
                if ((ulong)fileData.Length > availableBytes)
                {
                    throw new InvalidOperationException($"Not enough Steam Cloud space. Need {fileData.Length} bytes, have {availableBytes} bytes available.");
                }

                DebugConsole.Log($"SteamCloudUploader: Uploading {fileData.Length} bytes to {cloudFileName}");

                // Upload to Steam Cloud
                bool success = SteamRemoteStorage.FileWrite(cloudFileName, fileData, fileData.Length);

                if (!success)
                {
                    throw new InvalidOperationException("Steam Cloud upload failed - FileWrite returned false");
                }

                // Verify the upload
                if (!SteamRemoteStorage.FileExists(cloudFileName))
                {
                    throw new InvalidOperationException("Upload verification failed - file does not exist in Steam Cloud");
                }

                int uploadedSize = SteamRemoteStorage.GetFileSize(cloudFileName);
                if (uploadedSize != fileData.Length)
                {
                    throw new InvalidOperationException($"Upload size mismatch: expected {fileData.Length}, got {uploadedSize}");
                }

                DebugConsole.Log($"SteamCloudUploader: Successfully uploaded {cloudFileName} ({fileData.Length} bytes)");
                
                // Notify completion on main thread
                MainThreadExecutor.dispatcher.QueueEvent(() =>
                {
                    IsUploading = false;
                    MultiplayerOverlay.Show($"Upload complete: {cloudFileName}");
                    OnUploadFinished?.Invoke(cloudFileName);
                });
            }
            catch (Exception ex)
            {
                DebugConsole.LogError($"SteamCloudUploader: Upload error: {ex.Message}", false);
                
                // Notify failure on main thread
                MainThreadExecutor.dispatcher.QueueEvent(() =>
                {
                    IsUploading = false;
                    MultiplayerOverlay.Show($"Upload failed: {ex.Message}");
                    OnUploadFailed?.Invoke(ex);
                });
            }
        }

        /// <summary>
        /// Deletes a file from Steam Cloud.
        /// </summary>
        public bool DeleteFile(string cloudFileName)
        {
            if (!SteamCloud.Instance.IsInitialized)
            {
                DebugConsole.LogError("SteamCloudUploader: Steam Cloud not initialized!", false);
                return false;
            }

            if (!SteamRemoteStorage.FileExists(cloudFileName))
            {
                DebugConsole.LogWarning($"SteamCloudUploader: File {cloudFileName} does not exist in Steam Cloud");
                return false;
            }

            bool success = SteamRemoteStorage.FileDelete(cloudFileName);
            
            if (success)
            {
                DebugConsole.Log($"SteamCloudUploader: Successfully deleted {cloudFileName}");
            }
            else
            {
                DebugConsole.LogError($"SteamCloudUploader: Failed to delete {cloudFileName}", false);
            }

            return success;
        }

        /// <summary>
        /// Gets a list of save files in Steam Cloud.
        /// </summary>
        public string[] GetSaveFileList()
        {
            if (!SteamCloud.Instance.IsInitialized)
                return new string[0];

            string[] allFiles = SteamCloud.Instance.GetFileList();
            System.Collections.Generic.List<string> saveFiles = new System.Collections.Generic.List<string>();

            foreach (string file in allFiles)
            {
                if (file.StartsWith(SAVE_FILE_PREFIX))
                {
                    saveFiles.Add(file);
                }
            }

            return saveFiles.ToArray();
        }
    }
}
