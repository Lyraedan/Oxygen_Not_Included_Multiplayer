using ONI_MP.DebugTools;
using ONI_MP.Networking.Packets.Architecture;
using ONI_MP.Networking.States;
using ONI_MP.Misc;
using System;
using System.IO;

namespace ONI_MP.Networking.Packets.Cloud
{
    /// <summary>
    /// Packet for sharing Steam Cloud file information between players.
    /// Replaces GoogleDriveFileSharePacket when using Steam Cloud.
    /// </summary>
    public class SteamCloudFileSharePacket : IPacket
    {
        public string FileName { get; set; } = "";
        public string CloudFileName { get; set; } = "";
        public int FileSize { get; set; } = 0;
        public System.DateTime Timestamp { get; set; } = System.DateTime.MinValue;

        public PacketType Type => PacketType.SteamCloudFileShare;

        public void Serialize(BinaryWriter writer)
        {
            writer.Write(FileName ?? "");
            writer.Write(CloudFileName ?? "");
            writer.Write(FileSize);
            writer.Write(Timestamp.ToBinary());
        }

        public void Deserialize(BinaryReader reader)
        {
            FileName = reader.ReadString();
            CloudFileName = reader.ReadString();
            FileSize = reader.ReadInt32();
            Timestamp = System.DateTime.FromBinary(reader.ReadInt64());
        }

        public void OnDispatched()
        {
            if (MultiplayerSession.IsHost)
            {
                return; // Host does nothing here
            }

            if (Utils.IsInGame())
            {
                return;
            }

            try
            {
                DebugConsole.Log($"[SteamCloudFileSharePacket] Received file share for {FileName}: {CloudFileName} ({FileSize} bytes)");

                // Download and load the save file using Steam Cloud
                if (!string.IsNullOrEmpty(CloudFileName) && !string.IsNullOrEmpty(FileName))
                {
                    ONI_MP.Cloud.SteamCloudUtils.DownloadAndLoadSaveFile(CloudFileName, FileName);
                }
                else
                {
                    DebugConsole.LogError("[SteamCloudFileSharePacket] Invalid file information received", false);
                }
            }
            catch (Exception ex)
            {
                DebugConsole.LogError($"[SteamCloudFileSharePacket] Error processing packet: {ex.Message}", false);
            }
        }
    }
}
