﻿using HarmonyLib;
using ONI_MP.Networking.Components;
using UnityEngine;

namespace ONI_MP.Patches.World
{
	[HarmonyPatch(typeof(Substance), nameof(Substance.SpawnResource))]
	public static class Substance_SpawnResource_Patch
	{
		public static void Postfix(GameObject __result)
		{
			if (__result == null)
				return;

			NetworkIdentity identity = __result.AddOrGet<NetworkIdentity>();
			identity.RegisterIdentity();
		}
	}

}
